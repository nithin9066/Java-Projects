package com.crud;

import org.springframework.data.repository.CrudRepository;

public interface Repo extends CrudRepository<Users, Integer>  {

}
